"""00_validate.py - Appendix Table A1: validate the hand-coded estimators in econ.py against
published critical values and alternative computations. Output: results/validation.json
"""
import os, sys, json, itertools, warnings
import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from econ import *  # noqa

OUT = os.path.join(HERE, "results"); os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(99)
V = {}

# Dickey-Fuller 5% critical values, T = 40 (20,000 draws, no augmentation)
dfc, dft = [], []
for _ in range(20000):
    y = np.cumsum(rng.standard_normal(40))
    dfc.append(adf(y, "c", lag=0)[0]); dft.append(adf(y, "ct", lag=0)[0])
V["DF_c_5"] = float(np.quantile(dfc, .05)); V["DF_ct_5"] = float(np.quantile(dft, .05))

# KPSS 5% level critical value (T = 500, 3,000 draws, 0 lags under iid errors)
V["KPSS_5"] = float(np.quantile([kpss(rng.standard_normal(500), "c", L=0) for _ in range(3000)], .95))

# PSS bounds, Case III, k = 4, T = 500, ARDL(1,1,1,1,1), 10,000 draws
for lab, o in [("I0", [0] * 4), ("I1", [1] * 4)]:
    F, T = simulate_bounds(500, 1, (1, 1, 1, 1), 4, reps=10000, orders=o, seed=5, start=1)
    V[f"PSS_F_{lab}"] = float(np.quantile(F, .95)); V[f"PSS_t_{lab}"] = float(np.quantile(T, .05))

# Zivot-Andrews Model C 5% (T = 100, 1,500 draws, no augmentation)
V["ZA_C_5"] = float(np.quantile([za(np.cumsum(rng.standard_normal(100)), maxlag=0)[0] for _ in range(1500)], .05))

# Bai-Perron dynamic programme vs brute force (actual ln RET, 2 breaks)
d = pd.read_csv(os.path.join(HERE, "data", "quarterly.csv"), index_col=0).loc[:"2025Q4"]
y = d.lnRET.values; n = len(y); h = int(np.ceil(.15 * n)); tt = np.arange(n, dtype=float)
bp = bai_perron(y, 2, .15)[2]
best = (np.inf, None)
for b1 in range(h, n - h + 1):
    for b2 in range(b1 + h, n - h + 1):
        s = sum(OLS(y[a:b], np.column_stack([np.ones(b - a), tt[a:b]])).ssr for a, b in [(0, b1), (b1, b2), (b2, n)])
        if s < best[0]:
            best = (s, [b1, b2])
V["BP_identical"] = bool(bp[1] == best[1] and abs(bp[0] - best[0]) < 1e-12)

# OLS (QR) vs normal equations and lstsq, on the Model 1 ECM
X = d[["ECOM", "lnGDP", "UNR", "lnWAGE_real"]].values; fx = d[["D_COVID"]].values
a = ARDL(y, X, 1, (2, 0, 1, 0), fixed=fx)
b_ne = np.linalg.solve(a.Z.T @ a.Z, a.Z.T @ a.Y); b_ls = np.linalg.lstsq(a.Z, a.Y, rcond=None)[0]
V["OLS_maxdiff_fitted"] = float(max(np.abs(a.m.fit - a.Z @ b_ne).max(), np.abs(a.m.fit - a.Z @ b_ls).max()))
# recursive residuals: sum of squares equals full-sample SSR
# (full-rank simulated design with n = 36 and 10 regressors, as in Model 1)
Zs = np.column_stack([np.ones(36), rng.standard_normal((36, 9))]); ys = Zs @ rng.standard_normal(10) + rng.standard_normal(36)
w = recursive_residuals(ys, Zs)
V["recres_ssr_reldiff"] = float(abs(w @ w - OLS(ys, Zs).ssr) / OLS(ys, Zs).ssr)

# ECM form vs ARDL levels form: identical long-run coefficients and bounds F (restricted/unrestricted SSR)
t = np.arange(4, n)
lev = [np.ones(len(t)), y[t - 1], X[t, 0], X[t - 1, 0], X[t - 2, 0], X[t, 1], X[t, 2], X[t - 1, 2], X[t, 3], fx[t, 0]]
L = OLS(y[t], np.column_stack(lev))
bL = L.b
theta_lev = np.array([(bL[2] + bL[3] + bL[4]), bL[5], (bL[6] + bL[7]), bL[8]]) / (1 - bL[1])
V["ECM_vs_levels_maxdiff"] = float(np.abs(theta_lev - a.theta).max())
json.dump(V, open(os.path.join(OUT, "validation.json"), "w"), indent=1)
print(json.dumps(V, indent=1))

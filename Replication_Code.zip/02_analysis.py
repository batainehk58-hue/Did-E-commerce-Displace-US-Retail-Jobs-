"""02_analysis.py - Every estimate reported in the paper (Tables 1-8, text statistics).
Run after 01_data.py. Writes results/results.json and results/results.txt.
Random seeds are fixed, so all simulated and bootstrap quantities are reproducible.
Runtime: roughly 15 minutes on a laptop (dominated by the robustness bounds simulations).
"""
import os, sys, json, warnings
import numpy as np
import pandas as pd
from scipy import stats

warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from econ import *  # noqa

OUT = os.path.join(HERE, "results"); os.makedirs(OUT, exist_ok=True)
R_BOUNDS, R_BOOT, R_TY, R_ROB = 10000, 1999, 2000, 5000
FAST = "--fast" in sys.argv
if FAST:
    R_BOUNDS, R_BOOT, R_TY, R_ROB = 1000, 299, 199, 300

A = pd.read_csv(os.path.join(HERE, "data", "quarterly.csv"), index_col=0)
Aeoq = pd.read_csv(os.path.join(HERE, "data", "quarterly_eoq.csv"), index_col=0)
for D_ in (A, Aeoq):
    D_["lnNET"] = np.log(D_["NET"])
d = A.loc[:"2025Q4"].copy()
Q = list(d.index); n = len(d)
XV = ["ECOM", "lnGDP", "UNR", "lnWAGE_real"]
DEPS = ["lnRET", "lnWAR", "lnNET"]
res = {}
lines = []


def log(*a):
    s = " ".join(str(x) for x in a); print(s, flush=True); lines.append(s)


def nw_lags(T):
    """Newey-West (1994) rule of thumb: floor(4 (T/100)^(2/9)); = 3 for T = 36-40."""
    return int(np.floor(4 * (T / 100) ** (2 / 9)))


# ------------------------------------------------------------------ Table 1 and stylised facts
log("=== Table 1: mean (SD) ===")
pre, post = d.loc[:"2020Q1"], d.loc["2020Q2":]
t1 = {}
for v in ["RET", "WAR", "NET", "ECOM", "GDP", "UNR", "WAGE", "WAGE_real"]:
    t1[v] = [d[v].mean(), d[v].std(), pre[v].mean(), pre[v].std(), post[v].mean(), post[v].std(), 100 * d[v].std() / d[v].mean()]
    log(v, np.round(t1[v], 2))
res["table1"] = t1
sf = {
    "ECOM_2016Q1": d.ECOM.iloc[0], "ECOM_2025Q4": d.ECOM.iloc[-1], "ECOM_ratio": d.ECOM.iloc[-1] / d.ECOM.iloc[0],
    "WAR_2016Q1": d.WAR.iloc[0], "WAR_2025Q4": d.WAR.iloc[-1], "WAR_gain": d.WAR.iloc[-1] - d.WAR.iloc[0],
    "RET_change": d.RET.iloc[-1] - d.RET.iloc[0], "RET_change_pct": 100 * (d.RET.iloc[-1] / d.RET.iloc[0] - 1),
    "NET_change": d.NET.iloc[-1] - d.NET.iloc[0],
    "WAR_peak_q": d.WAR.idxmax(), "WAR_peak": d.WAR.max(),
    "WAR_fall_to_2023Q3_pct": 100 * (d.WAR["2023Q3"] / d.WAR.max() - 1),
    "RET_2025_avg": A.RET[A.index.str.startswith("2025")].mean(), "RET_2020_avg": A.RET[A.index.str.startswith("2020")].mean(),
    "pre_dECOM": d.ECOM["2020Q1"] - d.ECOM["2016Q1"], "pre_dRET": d.RET["2020Q1"] - d.RET["2016Q1"],
    "post_dECOM": d.ECOM["2025Q4"] - d.ECOM["2020Q1"], "post_dRET_pct": 100 * (d.RET["2025Q4"] / d.RET["2020Q1"] - 1),
    "RET_band_excl_2020Q2_2021Q4": list(100 * (d.RET.drop(d.loc["2020Q2":"2021Q4"].index) / d.RET.iloc[0] - 1).agg(["min", "max"])),
    "RET_drop_2020Q2": d.RET["2020Q1"] - d.RET["2020Q2"],
}
res["stylised"] = sf
log("=== Stylised facts ===")
for k, v in sf.items():
    log(k, v)

# Figure 3 descriptive slopes
fig3 = {}
for lab, sl in [("pre_2016Q1_2020Q1", slice(0, 17)), ("post_2020Q4_2025Q4", slice(19, 40)), ("post_2020Q2_2025Q4", slice(17, 40))]:
    x = d.ECOM.values[sl]; y = d.lnRET.values[sl]
    m = OLS(y, np.column_stack([np.ones(len(x)), x]), hac_lags=nw_lags(len(x)))
    fig3[lab] = dict(slope_pct=100 * m.b[1], p_hac=m.p[1], corr=np.corrcoef(x, y)[0, 1])
fig3["pooled_corr"] = np.corrcoef(d.ECOM, d.lnRET)[0, 1]
res["fig3"] = fig3
log("Fig3", fig3)

# ------------------------------------------------------------------ Table 2 unit roots
log("=== Table 2 ===")
t2 = {}
for v in ["lnRET", "lnWAR", "lnNET", "ECOM", "lnGDP", "UNR", "lnWAGE_real"]:
    y = d[v].values; dy = np.diff(y)
    z = za(y)
    t2[v] = dict(adf_c=adf(y, "c")[0], adf_ct=adf(y, "ct")[0], pp_c=pp(y, "c"), kpss_c=kpss(y, "c"),
                 adf_d=adf(dy, "c")[0], pp_d=pp(dy, "c"), kpss_d=kpss(dy, "c"), za=z[0], za_break=Q[z[1]])
    log(v, {k: (round(x, 3) if isinstance(x, float) else x) for k, x in t2[v].items()})
z = za(np.diff(d.lnWAR.values)); t2["dlnWAR_za"] = (z[0], Q[z[1] + 1])
log("ZA d lnWAR", t2["dlnWAR_za"])
res["table2"] = t2

# ------------------------------------------------------------------ Table 3 ARDL
log("=== Table 3 ===")
X = d[XV].values; fx = d[["D_COVID"]].values
t3 = {}; models = {}
for dep in DEPS:
    y = d[dep].values
    p, q = select_ardl(y, X, fixed=fx)
    a = ARDL(y, X, p, q, fixed=fx); models[dep] = a
    out = dict(order=[p] + list(q), F=a.F, t=a.t_phi, phi=a.phi, half_life=a.half_life, adj_r2=a.m.r2_adj, n=a.m.n,
               theta=list(a.theta), se_hac=list(a.se_hac), se_ols=list(a.se_ols),
               p_hac=list(2 * stats.t.sf(np.abs(a.theta / a.se_hac), a.m.df)))
    for lab, o in [("I0", [0] * 4), ("I1", [1] * 4), ("mixed", [1, 1, 0, 1])]:
        F, T = simulate_bounds(n, p, q, 4, fixed=fx, reps=R_BOUNDS, orders=o, seed=2025)
        out[lab] = dict(F_cv5=np.quantile(F, .95), t_cv5=np.quantile(T, .05), pF=np.mean(F >= a.F), pt=np.mean(T <= a.t_phi))
    m = a.m_ols
    lev_fit = y[3:-1] + m.fit
    out["diag"] = dict(BG4=breusch_godfrey(m, 4), BP=breusch_pagan(m), JB=jarque_bera(m),
                       RESET2=reset(m, 2, lev_fit), RESET3=reset(m, 3, lev_fit))
    B = ardl_bootstrap(y, X, p, q, fixed=fx, reps=R_BOOT, seed=7)
    out["boot_ci"] = list(np.percentile(B[:, 0], [2.5, 97.5]))
    out["boot_share_le_m0005"] = float(np.mean(B[:, 0] <= -0.005))
    # CUSUM / CUSUMSQ on the ECM regression
    W, band, S, w = cusum(m.y, m.X)
    kk = m.X.shape[1]
    line = np.arange(1, len(S) + 1) / len(S)
    cv = cusumsq_cv(m.n, kk)
    out["cusum_max_ratio"] = float(np.max(np.abs(W) / band))
    out["cusumsq_maxdev"] = float(np.max(np.abs(S - line))); out["cusumsq_cv"] = float(cv)
    out["one_sided_p_theta_ge0"] = float(stats.t.cdf(a.theta[0] / a.se_hac[0], a.m.df))
    if dep == "lnRET":
        i = a.names.index("dx0_l1"); out["sr_dECOM_l1"] = (a.m.b[i], a.m.p[i])
    t3[dep] = out
    log(dep, json.dumps(out, default=float))
Xc = d[XV].values
t3["VIF"] = [1 / (1 - OLS(Xc[:, j], np.column_stack([np.ones(n), np.delete(Xc, j, 1)])).r2) for j in range(4)]
t3["jobs_per_point_WAR"] = t3["lnWAR"]["theta"][0] * d.WAR.mean()
res["table3"] = t3
log("VIF", t3["VIF"], "jobs/pt", t3["jobs_per_point_WAR"])

# ------------------------------------------------------------------ Table 4 TOST / magnitudes
log("=== Table 4 ===")
a = models["lnRET"]; th = a.theta[0]; df_ = a.m.df
dECOM = d.ECOM.iloc[-1] - d.ECOM.iloc[0]; R0 = d.RET.iloc[0]
t4 = {"dECOM": dECOM}
for lab, se in [("HAC", a.se_hac[0]), ("OLS", a.se_ols[0])]:
    lo, hi = th - stats.t.ppf(.975, df_) * se, th + stats.t.ppf(.975, df_) * se
    t4[lab] = dict(theta=th, ci=[lo, hi], tost_p=stats.t.sf((th + 0.005) / se, df_),
                   smallest=100 * (th - stats.t.ppf(.95, df_) * se),
                   cum_pct=100 * (np.exp(dECOM * lo) - 1), cum_jobs=R0 * (np.exp(dECOM * lo) - 1))
lo = t3["lnRET"]["boot_ci"][0]
t4["boot"] = dict(ci=t3["lnRET"]["boot_ci"], share=t3["lnRET"]["boot_share_le_m0005"],
                  cum_pct=100 * (np.exp(dECOM * lo) - 1), cum_jobs=R0 * (np.exp(dECOM * lo) - 1))
t4["anticipated"] = dict(cum_pct=[100 * (np.exp(dECOM * x) - 1) for x in (-0.005, -0.015)],
                         cum_jobs=[R0 * (np.exp(dECOM * x) - 1) for x in (-0.005, -0.015)])


def first_diff(dep):
    y = np.diff(d[dep].values); t = np.arange(3, n - 1)
    dE = np.diff(d.ECOM.values)
    Z = np.column_stack([np.ones(len(t))] + [dE[t - l] for l in range(4)] +
                        [np.diff(d[v].values)[t] for v in ["lnGDP", "UNR", "lnWAGE_real"]] +
                        [d[c].values[t + 1] for c in ["I1", "I2", "I3"]])
    m = OLS(y[t], Z, hac_lags=3); mo = OLS(y[t], Z)
    Rv = np.zeros(Z.shape[1]); Rv[1:5] = 1
    s = Rv @ m.b; se = np.sqrt(Rv @ m.V @ Rv); seo = np.sqrt(Rv @ mo.V_ols @ Rv); dfm = m.df
    lo = s - stats.t.ppf(.975, dfm) * se
    return dict(theta=s, p_hac=2 * stats.t.sf(abs(s / se), dfm), p_ols=2 * stats.t.sf(abs(s / seo), dfm),
                ci=[lo, s + stats.t.ppf(.975, dfm) * se], tost_p=stats.t.sf((s + 0.005) / se, dfm),
                smallest=100 * (s - stats.t.ppf(.95, dfm) * se), cum_pct=100 * (np.exp(dECOM * lo) - 1),
                cum_jobs=R0 * (np.exp(dECOM * lo) - 1), n=m.n)


t4["FD"] = {dep: first_diff(dep) for dep in DEPS}
res["table4"] = t4
log(json.dumps(t4, default=float, indent=1))

# ------------------------------------------------------------------ Table 5 Toda-Yamamoto
log("=== Table 5 ===")
ex = d[["I1", "I2", "I3"]].values
t5 = {}
for i, v in enumerate(DEPS):
    Y = d[["ECOM", v]].values
    ka = var_lag_select(Y, 4, ex, "aic"); kb = var_lag_select(Y, 4, ex, "bic")
    Yt, Xv = var_design(Y, ka + 1, ex)
    bg = min(breusch_godfrey(OLS(Yt[:, j], Xv), 2) for j in range(2))
    for c, e, lab in [(1, 0, v + "->ECOM"), (0, 1, "ECOM->" + v)]:
        W, pa, m = ty_wald(Y, ka, 1, c, e, ex)
        pb = ty_bootstrap(Y, ka, 1, c, e, ex, reps=R_TY, seed=100 + i)
        pbic = ty_wald(Y, kb, 1, c, e, ex)[1]
        t5[lab] = dict(k=ka, chi2=W, p=pa, p_boot=pb, p_bic=pbic, minBG2=bg, n=m.n)
        log(lab, t5[lab])
Y = d[["ECOM", "lnRET"]].values; exc = d[["D_COVID"]].values; k = var_lag_select(Y, 4, exc, "aic")
Yt, Xv = var_design(Y, k + 1, exc)
t5["single_DCOVID"] = dict(k=k, p_RET_to_ECOM=ty_wald(Y, k, 1, 1, 0, exc)[1],
                           BG=min(breusch_godfrey(OLS(Yt[:, j], Xv), 2) for j in range(2)))
Y = d[["ECOM", "lnRET", "UNR"]].values; k = var_lag_select(Y, 4, ex, "aic")
t5["trivariate_UNR"] = dict(k=k, ECOM_to_RET=ty_wald(Y, k, 1, 0, 1, ex)[1], RET_to_ECOM=ty_wald(Y, k, 1, 1, 0, ex)[1])
log(t5["single_DCOVID"], t5["trivariate_UNR"])
res["table5"] = t5

# ------------------------------------------------------------------ Table 6 breaks
log("=== Table 6 ===")
tt = np.arange(n, dtype=float); Xt = np.column_stack([np.ones(n), tt])
t6 = {}
for v in ["lnRET", "lnWAR", "lnNET", "ECOM"]:
    F, p = chow(d[v].values, Xt, Q.index("2020Q2"))
    bp = bai_perron(d[v].values, 3, .15); cr = bp_criteria(bp, n)
    mb = min(cr, key=lambda m: cr[m][0]); ml = min(cr, key=lambda m: cr[m][1])
    bks = [0] + bp[mb][1] + [n]; segs = []
    for a_, b_ in zip(bks[:-1], bks[1:]):
        m = OLS(d[v].values[a_:b_], Xt[a_:b_], hac_lags=nw_lags(b_ - a_))
        segs.append(dict(seg=f"{Q[a_]}-{Q[b_ - 1]}", n=b_ - a_, slope=m.b[1], se=m.se[1], p=m.p[1]))
    t6[v] = dict(chow_F=F, chow_p=p, bic_breaks=[Q[b] for b in bp[mb][1]], lwz_breaks=[Q[b] for b in bp[ml][1]], segments=segs)
    log(v, json.dumps(t6[v], default=float))
pre_ = slice(0, 17); dev = {}
for v in ["lnRET", "ECOM"]:
    m = OLS(d[v].values[pre_], Xt[pre_]); tr = Xt @ m.b
    dev[v] = dict(actual=d[v].values[-1], trend=tr[-1], dev=d[v].values[-1] - tr[-1])
dev["lnRET"]["pct"] = 100 * (np.exp(dev["lnRET"]["dev"]) - 1)
dev["lnRET"]["jobs"] = d.RET.values[-1] - np.exp(dev["lnRET"]["trend"])
t6["pretrend"] = dev
# SBC: D_POST vs D_COVID (lags re-selected)
sbc = {}
for dep in DEPS:
    y = d[dep].values; out = {}
    for lab, c in [("D_COVID", ["D_COVID"]), ("D_POST", ["D_POST"])]:
        f_ = d[c].values; p, q = select_ardl(y, X, fixed=f_); out[lab] = ARDL(y, X, p, q, fixed=f_).m.bic
    sbc[dep] = out
t6["sbc"] = sbc
log("pretrend", dev, "SBC", sbc)
res["table6"] = t6

# ------------------------------------------------------------------ Real wages (H6)
w = d.lnWAGE_real.values
m1 = OLS(w, Xt, hac_lags=3); m2 = OLS(w, np.column_stack([Xt, d.D_POST.values]), hac_lags=3)
mpre = OLS(w[:17], Xt[:17]); mpost = OLS(w[17:], Xt[17:])
res["wages"] = dict(start=d.WAGE_real.iloc[0], end=d.WAGE_real.iloc[-1], real_pct=100 * (d.WAGE_real.iloc[-1] / d.WAGE_real.iloc[0] - 1),
                    nom_pct=100 * (d.WAGE.iloc[-1] / d.WAGE.iloc[0] - 1), cpi_pct=100 * (d.CPI.iloc[-1] / d.CPI.iloc[0] - 1),
                    trend_pct_yr=400 * m1.b[1], trend_p=m1.p[1], shift_pct=100 * (np.exp(m2.b[2]) - 1), shift_p=m2.p[2],
                    resid_trend_p=m2.p[1], pre_trend_pct_yr=400 * mpre.b[1], post_trend_pct_yr=400 * mpost.b[1],
                    jump_2020Q2_pct=100 * (d.WAGE_real["2020Q2"] / d.WAGE_real["2020Q1"] - 1),
                    low_after_2021=d.WAGE_real.loc["2021Q1":].idxmin())
log("wages", res["wages"])

# ------------------------------------------------------------------ Table 7 robustness
log("=== Table 7 ===")
specs = {
    "R1": dict(), "R2": dict(fix=None, drop=["2020Q2", "2020Q3", "2020Q4"]), "R3a": dict(fix=["D_POST"]),
    "R3b": dict(fix=["D_COVID", "D_POST"]), "R3c": dict(fix=["I1", "I2", "I3"]), "R4a": dict(trend=True),
    "R4b": dict(xv=["ECOM", "UNR", "lnWAGE_real"]), "R4c": dict(xv=["ECOM", "lnGDP", "UNR"]), "R4d": dict(xv=["ECOM", "UNR"]),
    "R5": dict(crit="aic"), "R6": dict(data="eoq"), "R7": dict(end="2026Q1"), "R8": dict(end="2025Q3")}
t7 = {}
for name, s in specs.items():
    D_ = (Aeoq if s.get("data") == "eoq" else A).loc[:s.get("end", "2025Q4")]
    xv = s.get("xv", XV); fixc = s["fix"] if "fix" in s else ["D_COVID"]
    f_ = None if fixc is None else D_[fixc].values
    drop = [list(D_.index).index(x) for x in s["drop"]] if "drop" in s else None
    Xs = D_[xv].values; tr = s.get("trend", False); row = {}
    for j, dep in enumerate(DEPS):
        y = D_[dep].values
        p, q = select_ardl(y, Xs, fixed=f_, crit=s.get("crit", "bic"), trend=tr, drop=drop)
        a = ARDL(y, Xs, p, q, fixed=f_, trend=tr, drop=drop)
        pv = 2 * stats.t.sf(abs(a.theta[0] / a.se_hac[0]), a.m.df)
        F0, T0 = simulate_bounds(len(D_), p, q, Xs.shape[1], fixed=f_, reps=R_ROB, orders=[0] * len(xv), seed=31 + j, trend=tr, drop=drop)
        F1, T1 = simulate_bounds(len(D_), p, q, Xs.shape[1], fixed=f_, reps=R_ROB, orders=[1] * len(xv), seed=41 + j, trend=tr, drop=drop)
        f0, f1, c0, c1 = np.quantile(F0, .95), np.quantile(F1, .95), np.quantile(T0, .05), np.quantile(T1, .05)
        verdict = "Coint." if (a.F > f1 and a.t_phi < c1) else ("No" if (a.F < f0 or a.t_phi > c0) else "Incon.")
        row[dep] = dict(order=[p] + list(q), theta=a.theta[0], p=pv, verdict=verdict, phi=a.phi, F=a.F, t=a.t_phi,
                        bounds=[f0, f1, c0, c1], pF_I1=np.mean(F1 >= a.F), pt_I1=np.mean(T1 <= a.t_phi),
                        BG=breusch_godfrey(a.m_ols, 4), n=a.m.n)
    t7[name] = row
    log(name, " || ".join(f"{k}: {v['theta']:.4f} p={v['p']:.3f} {v['verdict']} (pt_I1={v['pt_I1']:.3f}) phi={v['phi']:.3f} BG={v['BG']:.3f}" for k, v in row.items()))
res["table7"] = t7


def conv(o):
    if isinstance(o, dict): return {k: conv(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)): return [conv(v) for v in o]
    if isinstance(o, (np.floating, np.integer)): return o.item()
    return o


json.dump(conv(res), open(os.path.join(OUT, "results.json"), "w"), indent=1)
open(os.path.join(OUT, "results.txt"), "w").write("\n".join(lines))
log("done")

"""econ.py - Estimators used in the paper, implemented with numpy/scipy only.

OLS with Newey-West HAC, ADF/PP/KPSS/Zivot-Andrews unit-root tests, ARDL/conditional ECM
with bounds tests and simulated finite-sample critical values, delta-method long-run
coefficients, recursive residual bootstrap, residual diagnostics, CUSUM/CUSUMSQ,
Toda-Yamamoto Wald tests with bootstrap, Chow and Bai-Perron break tests.
"""
import itertools
import numpy as np
from scipy import stats


# ----------------------------------------------------------------------------- OLS
class OLS:
    def __init__(self, y, X, hac_lags=None):
        y = np.asarray(y, float); X = np.asarray(X, float)
        self.y, self.X = y, X
        self.n, self.k = X.shape
        Q, R = np.linalg.qr(X)
        self.b = np.linalg.solve(R, Q.T @ y)
        self.fit = X @ self.b
        self.e = y - self.fit
        self.ssr = float(self.e @ self.e)
        self.df = self.n - self.k
        self.s2 = self.ssr / self.df
        self.XtXi = np.linalg.inv(X.T @ X)
        self.V_ols = self.s2 * self.XtXi
        self.V = self.V_ols if hac_lags is None else self.hac(hac_lags)
        self.se = np.sqrt(np.diag(self.V))
        self.t = self.b / self.se
        self.p = 2 * stats.t.sf(np.abs(self.t), self.df)
        tss = float(((y - y.mean()) ** 2).sum())
        self.r2 = 1 - self.ssr / tss
        self.r2_adj = 1 - (1 - self.r2) * (self.n - 1) / self.df
        ll = -self.n / 2 * (np.log(2 * np.pi) + np.log(self.ssr / self.n) + 1)
        self.llf = ll
        self.aic = -2 * ll + 2 * self.k
        self.bic = -2 * ll + np.log(self.n) * self.k

    def hac(self, L):
        """Newey-West (Bartlett) HAC covariance with small-sample correction n/(n-k)."""
        X, e = self.X, self.e
        u = X * e[:, None]
        S = u.T @ u
        for l in range(1, L + 1):
            w = 1 - l / (L + 1)
            G = u[l:].T @ u[:-l]
            S += w * (G + G.T)
        return self.n / self.df * self.XtXi @ S @ self.XtXi

    def wald(self, R, r=None, V=None):
        R = np.atleast_2d(R); r = np.zeros(R.shape[0]) if r is None else r
        V = self.V if V is None else V
        d = R @ self.b - r
        W = float(d @ np.linalg.solve(R @ V @ R.T, d))
        return W

    def ftest(self, idx):
        """Classical F test that coefficients idx are jointly zero (restricted vs unrestricted SSR)."""
        keep = [j for j in range(self.k) if j not in idx]
        rr = OLS(self.y, self.X[:, keep])
        q = len(idx)
        F = ((rr.ssr - self.ssr) / q) / (self.ssr / self.df)
        return F, stats.f.sf(F, q, self.df)


def lagmat(x, L):
    x = np.asarray(x, float)
    out = np.full((len(x), L), np.nan)
    for l in range(1, L + 1):
        out[l:, l - 1] = x[:-l]
    return out


# ----------------------------------------------------------------------------- unit roots
def adf(y, trend="c", maxlag=4, lag=None):
    """ADF t-statistic; lag chosen by AIC on a common sample (maxlag), then re-estimated."""
    y = np.asarray(y, float)
    dy = np.diff(y)
    T = len(dy)

    def design(p, start):
        Y = dy[start:]
        cols = [y[start:-1]]
        for i in range(1, p + 1):
            cols.append(dy[start - i:T - i])
        X = np.column_stack(cols + [np.ones(T - start)])
        if trend == "ct":
            X = np.column_stack([X, np.arange(start + 1, T + 1)])
        return Y, X

    if lag is None:
        best = None
        for p in range(maxlag + 1):
            Y, X = design(p, maxlag)
            m = OLS(Y, X)
            if best is None or m.aic < best[0] - 1e-12:
                best = (m.aic, p)
        lag = best[1]
    Y, X = design(lag, lag)
    m = OLS(Y, X)
    return m.t[0], lag


def pp(y, trend="c", L=3):
    """Phillips-Perron Z_t statistic (Bartlett kernel, L lags)."""
    y = np.asarray(y, float)
    Y = y[1:]
    X = np.column_stack([y[:-1], np.ones(len(Y))])
    if trend == "ct":
        X = np.column_stack([X, np.arange(1, len(Y) + 1)])
    m = OLS(Y, X)
    e = m.e; T = len(e)
    g0 = e @ e / T
    lam2 = g0 + 2 * sum((1 - l / (L + 1)) * (e[l:] @ e[:-l]) / T for l in range(1, L + 1))
    s2 = m.ssr / m.df
    se = m.se[0]
    tr = (m.b[0] - 1) / se
    Zt = np.sqrt(g0 / lam2) * tr - (lam2 - g0) / (2 * np.sqrt(lam2)) * (T * se / np.sqrt(s2))
    return Zt


def kpss(y, trend="c", L=3):
    y = np.asarray(y, float); T = len(y)
    X = np.ones((T, 1)) if trend == "c" else np.column_stack([np.ones(T), np.arange(1, T + 1)])
    e = OLS(y, X).e
    S = np.cumsum(e)
    lam2 = e @ e / T + 2 * sum((1 - l / (L + 1)) * (e[l:] @ e[:-l]) / T for l in range(1, L + 1))
    return (S @ S) / (T ** 2 * lam2)


def za(y, model="C", trim=0.15, maxlag=4):
    """Zivot-Andrews test (Model C: break in intercept and trend). Lag by general-to-specific
    (drop the last lag while |t| < 1.645). Returns (min t, break index = first obs of new regime)."""
    y = np.asarray(y, float); n = len(y)
    dy = np.diff(y)
    best = (np.inf, None, None)
    lo, hi = int(np.floor(trim * n)), int(np.ceil((1 - trim) * n))
    for tb in range(max(lo, 2), hi):
        for p in range(maxlag, -1, -1):
            start = p + 1
            idx = np.arange(start, n)
            Y = y[idx]
            cols = [np.ones(len(idx)), idx.astype(float), (idx >= tb).astype(float)]
            if model in ("C", "B"):
                cols.append(np.where(idx >= tb, idx - tb + 1, 0).astype(float))
            if model == "B":
                cols.pop(2)
            cols.append(y[idx - 1])
            for i in range(1, p + 1):
                cols.append(dy[idx - 1 - i])
            X = np.column_stack(cols)
            m = OLS(Y, X)
            if p == 0 or abs(m.t[-1]) >= 1.645:
                break
        jpos = 4 if model == "C" else 3
        tstat = (m.b[jpos] - 1) / m.se[jpos]
        if tstat < best[0]:
            best = (tstat, tb, p)
    return best


# ----------------------------------------------------------------------------- ARDL / ECM
def ecm_design(y, X, p, q, fixed=None, start=4, trend=False, drop=None):
    """Conditional ECM (Case III, or Case V if trend):
    dy_t = c + phi*y_{t-1} + sum_j beta_j x_{j,t-1} + sum_{i=1}^{p-1} psi_i dy_{t-i}
           + sum_j sum_{l=0}^{q_j-1} w_{jl} dx_{j,t-l} + fixed_t  (+ trend)
    Equivalent to ARDL(p, q_1..q_k) in levels. Returns Y, Z, names, index of levels block.
    Sample starts at observation `start` (common sample)."""
    y = np.asarray(y, float); X = np.asarray(X, float)
    n, k = X.shape
    dy = np.r_[np.nan, np.diff(y)]
    dX = np.vstack([np.full(k, np.nan), np.diff(X, axis=0)])
    t = np.arange(start, n)
    if drop is not None:                       # observations excluded from the estimation sample
        t = np.array([i for i in t if i not in set(drop)])
    cols, names = [np.ones(len(t))], ["const"]
    if trend:
        cols.append(t.astype(float)); names.append("trend")
    lev0 = len(cols)
    cols.append(y[t - 1]); names.append("y_l1")
    for j in range(k):
        # ARDL(p, q) in levels with q_j = 0 contains x_{j,t} only; in ECM form this is the
        # level term dated t (Pesaran et al., 2001, eq. 6 with no short-run dx terms).
        lag = 0 if q[j] == 0 else 1
        cols.append(X[t - lag, j]); names.append(f"x{j}_l{lag}")
    for i in range(1, p):
        cols.append(dy[t - i]); names.append(f"dy_l{i}")
    for j in range(k):
        for l in range(0, q[j]):
            cols.append(dX[t - l, j]); names.append(f"dx{j}_l{l}")
    if fixed is not None:
        F = np.atleast_2d(np.asarray(fixed, float).T).T if np.ndim(fixed) == 1 else np.asarray(fixed, float)
        if F.ndim == 1:
            F = F[:, None]
        for c in range(F.shape[1]):
            cols.append(F[t, c]); names.append(f"fix{c}")
    Z = np.column_stack(cols)
    return dy[t], Z, names, lev0


class ARDL:
    def __init__(self, y, X, p, q, fixed=None, start=4, trend=False, hac_lags=3, drop=None):
        self.p, self.q, self.k = p, list(q), X.shape[1]
        self.Y, self.Z, self.names, self.lev0 = ecm_design(y, X, p, q, fixed, start, trend, drop)
        self.m = OLS(self.Y, self.Z, hac_lags=hac_lags)
        self.m_ols = OLS(self.Y, self.Z)
        i = self.lev0
        self.phi = self.m.b[i]
        self.t_phi = self.m_ols.t[i]            # bounds t statistic (conventional s.e.)
        self.levels = list(range(i, i + 1 + self.k))
        self.F = self.m_ols.ftest(self.levels)[0]
        self.theta = -self.m.b[i + 1:i + 1 + self.k] / self.phi
        self.half_life = np.log(0.5) / np.log(1 + self.phi) if -1 < self.phi < 0 else np.nan

    def lr_se(self, V):
        i, k = self.lev0, self.k
        phi = self.phi; beta = self.m.b[i + 1:i + 1 + k]
        idx = [i] + list(range(i + 1, i + 1 + k))
        Vs = V[np.ix_(idx, idx)]
        se = []
        for j in range(k):
            g = np.zeros(k + 1)
            g[0] = beta[j] / phi ** 2
            g[j + 1] = -1 / phi
            se.append(np.sqrt(g @ Vs @ g))
        return np.array(se)

    @property
    def se_hac(self):
        return self.lr_se(self.m.V)

    @property
    def se_ols(self):
        return self.lr_se(self.m_ols.V_ols)


def select_ardl(y, X, maxp=4, maxq=4, fixed=None, start=4, crit="bic", trend=False, drop=None):
    best = None
    k = X.shape[1]
    for p in range(1, maxp + 1):
        for q in itertools.product(range(maxq + 1), repeat=k):
            a = ARDL(y, X, p, q, fixed, start, trend, hac_lags=None, drop=drop)
            v = a.m.bic if crit == "bic" else a.m.aic
            if best is None or v < best[0] - 1e-12:
                best = (v, p, q)
    return best[1], best[2]


def simulate_bounds(n_obs, p, q, k, fixed=None, reps=10000, orders=None, seed=0, start=4, trend=False, drop=None):
    """Finite-sample null distribution of the bounds F and t statistics for the given lag
    structure. Under H0 (no level relationship): y is a random walk independent of x;
    x_j are I(0) (white noise) or I(1) (random walks) according to `orders` (list of 0/1).
    Returns arrays of F and t."""
    rng = np.random.default_rng(seed)
    Fs, ts = np.empty(reps), np.empty(reps)
    for r in range(reps):
        e = rng.standard_normal((n_obs, k + 1))
        y = np.cumsum(e[:, 0])
        Xs = np.empty((n_obs, k))
        for j in range(k):
            Xs[:, j] = np.cumsum(e[:, j + 1]) if orders[j] == 1 else e[:, j + 1]
        a = ARDL(y, Xs, p, q, fixed, start, trend, hac_lags=None, drop=drop)
        Fs[r], ts[r] = a.F, a.t_phi
    return Fs, ts


# ----------------------------------------------------------------------------- diagnostics
def breusch_godfrey(m, lags=4):
    e = m.e; n = len(e)
    E = lagmat(e, lags); E[np.isnan(E)] = 0
    aux = OLS(e, np.column_stack([m.X, E]))
    LM = n * aux.r2
    return stats.chi2.sf(LM, lags)


def breusch_pagan(m):
    e2 = m.e ** 2
    X = m.X
    aux = OLS(e2, X)
    LM = len(e2) * aux.r2
    return stats.chi2.sf(LM, X.shape[1] - 1)


def jarque_bera(m):
    e = m.e - m.e.mean(); n = len(e)
    s = (e ** 3).mean() / (e ** 2).mean() ** 1.5
    kk = (e ** 4).mean() / (e ** 2).mean() ** 2
    JB = n / 6 * (s ** 2 + (kk - 3) ** 2 / 4)
    return stats.chi2.sf(JB, 2)


def reset(m, power=2, fitted=None):
    """Ramsey RESET. `fitted` = fitted values of the ARDL levels equation (ln y_t); for an ECM
    these are y_{t-1} + fitted(dy_t). power=2: fitted^2; power=3: fitted^2 and fitted^3."""
    f = m.fit if fitted is None else fitted
    add = np.column_stack([f ** j for j in range(2, power + 1)])
    u = OLS(m.y, np.column_stack([m.X, add]))
    q = add.shape[1]
    F = ((m.ssr - u.ssr) / q) / (u.ssr / u.df)
    return stats.f.sf(F, q, u.df)


def recursive_residuals(y, X):
    n, k = X.shape
    w = []
    for t in range(k, n):
        # minimum-norm (pseudo-inverse) solution: early subsamples can be rank deficient
        # because the 2020 dummies are zero before 2020Q2
        Xt = X[:t]
        b = np.linalg.lstsq(Xt, y[:t], rcond=None)[0]
        xt = X[t]
        f = 1 + xt @ np.linalg.pinv(Xt.T @ Xt) @ xt
        w.append((y[t] - xt @ b) / np.sqrt(f))
    return np.array(w)


def cusum(y, X):
    w = recursive_residuals(y, X)
    n, k = X.shape
    s = w.std(ddof=1)
    W = np.cumsum(w) / s
    r = np.arange(k + 1, n + 1)
    band = 0.948 * (np.sqrt(n - k) + 2 * (r - k) / np.sqrt(n - k))
    S = np.cumsum(w ** 2) / (w @ w)
    return W, band, S, w


def cusumsq_cv(n, k, reps=20000, alpha=0.05, seed=1):
    """Simulated 5% critical value of max |S_r - (r-k)/(n-k)| (Brown-Durbin-Evans)."""
    rng = np.random.default_rng(seed)
    m = n - k
    E = rng.standard_normal((reps, m)) ** 2
    S = np.cumsum(E, 1) / E.sum(1, keepdims=True)
    line = np.arange(1, m + 1) / m
    D = np.abs(S - line).max(1)
    return np.quantile(D, 1 - alpha)


# ----------------------------------------------------------------------------- VAR / Toda-Yamamoto
def var_design(Y, L, exog=None, start=None):
    n, m = Y.shape
    start = L if start is None else start
    t = np.arange(start, n)
    cols = [np.ones(len(t))]
    for l in range(1, L + 1):
        cols.append(Y[t - l])
    if exog is not None:
        cols.append(exog[t])
    return Y[t], np.column_stack(cols)


def var_lag_select(Y, maxL=4, exog=None, crit="aic"):
    best = None
    for L in range(1, maxL + 1):
        Yt, X = var_design(Y, L, exog, start=maxL)
        B = np.linalg.lstsq(X, Yt, rcond=None)[0]
        E = Yt - X @ B
        T = len(Yt)
        Sig = E.T @ E / T
        kk = X.shape[1] * Y.shape[1]
        ld = np.log(np.linalg.det(Sig))
        v = ld + (2 * kk / T if crit == "aic" else np.log(T) * kk / T)
        if best is None or v < best[0]:
            best = (v, L)
    return best[1]


def ty_wald(Y, k, dmax, cause, effect, exog=None):
    """Toda-Yamamoto modified Wald test: VAR(k+dmax) in levels, test first k lags of `cause`
    in the `effect` equation (asymptotic chi2(k))."""
    L = k + dmax
    Yt, X = var_design(Y, L, exog)
    m = OLS(Yt[:, effect], X)
    nvar = Y.shape[1]
    idx = [1 + (l - 1) * nvar + cause for l in range(1, k + 1)]
    R = np.zeros((k, X.shape[1]))
    for i, j in enumerate(idx):
        R[i, j] = 1
    W = m.wald(R, V=m.V_ols)
    return W, stats.chi2.sf(W, k), m


def ty_bootstrap(Y, k, dmax, cause, effect, exog=None, reps=2000, seed=0):
    """Residual bootstrap under the null (Hacker & Hatemi-J, 2006)."""
    rng = np.random.default_rng(seed)
    L = k + dmax
    W0 = ty_wald(Y, k, dmax, cause, effect, exog)[0]
    n, nv = Y.shape
    Yt, X = var_design(Y, L, exog)
    # restricted estimation: effect equation without the k tested lags of cause
    idx = [1 + (l - 1) * nv + cause for l in range(1, k + 1)]
    B = np.linalg.lstsq(X, Yt, rcond=None)[0]
    keep = [j for j in range(X.shape[1]) if j not in idx]
    br = np.linalg.lstsq(X[:, keep], Yt[:, effect], rcond=None)[0]
    Br = B.copy(); Br[:, effect] = 0; Br[keep, effect] = br
    E = Yt - X @ Br
    E = E - E.mean(0)
    cnt = 0
    for r in range(reps):
        Es = E[rng.integers(0, len(E), len(E))]
        Ys = Y.copy()
        for i, t in enumerate(range(L, n)):
            x = [1.0]
            for l in range(1, L + 1):
                x.extend(Ys[t - l])
            if exog is not None:
                x.extend(exog[t])
            Ys[t] = np.array(x) @ Br + Es[i]
        Wb = ty_wald(Ys, k, dmax, cause, effect, exog)[0]
        cnt += Wb >= W0
    return (cnt + 1) / (reps + 1)


# ----------------------------------------------------------------------------- breaks
def chow(y, X, tb):
    n, k = X.shape
    r = OLS(y, X)
    a = OLS(y[:tb], X[:tb]); b = OLS(y[tb:], X[tb:])
    ssu = a.ssr + b.ssr
    F = ((r.ssr - ssu) / k) / (ssu / (n - 2 * k))
    return F, stats.f.sf(F, k, n - 2 * k)


def bai_perron(y, maxb=3, trim=0.15):
    """Global SSR minimisation (dynamic programming) for a segmented trend model
    y_t = a_j + b_j t. Returns dict m -> (ssr, breaks). Breaks are first obs of new segment."""
    y = np.asarray(y, float); n = len(y)
    h = int(np.ceil(trim * n))
    tt = np.arange(n, dtype=float)
    ssr = np.full((n, n + 1), np.inf)
    for i in range(n):
        for j in range(i + h, n + 1):
            X = np.column_stack([np.ones(j - i), tt[i:j]])
            ssr[i, j] = OLS(y[i:j], X).ssr
    res = {0: (ssr[0, n], [])}
    # opt[m][j]: min SSR of y[0:j] with m breaks
    opt = {0: {j: (ssr[0, j], []) for j in range(h, n + 1)}}
    for m in range(1, maxb + 1):
        opt[m] = {}
        for j in range((m + 1) * h, n + 1):
            best = (np.inf, None)
            for b in range(m * h, j - h + 1):
                if b in opt[m - 1]:
                    v = opt[m - 1][b][0] + ssr[b, j]
                    if v < best[0]:
                        best = (v, opt[m - 1][b][1] + [b])
            opt[m][j] = best
        res[m] = opt[m][n]
    return res


def bp_criteria(res, n, q=2):
    """BIC and LWZ (Liu, Wu & Zidek, 1997) for the number of breaks (q regime coefficients)."""
    out = {}
    for m, (s, _) in res.items():
        p = (m + 1) * q + m
        bic = np.log(s / n) + p * np.log(n) / n
        lwz = np.log(s / (n - p)) + p * 0.299 * np.log(n) ** 2.1 / n
        out[m] = (bic, lwz)
    return out


def ardl_bootstrap(y, X, p, q, fixed=None, start=4, reps=1999, seed=0, trend=False):
    """Recursive residual bootstrap of the conditional ARDL/ECM: regressors held fixed,
    y regenerated recursively from the estimated ECM with resampled (centred) residuals.
    Returns array (reps x k) of long-run coefficients."""
    rng = np.random.default_rng(seed)
    y = np.asarray(y, float)
    a = ARDL(y, X, p, q, fixed, start, trend, hac_lags=None)
    b = a.m.b; Z0 = a.Z.copy(); e = a.m.e - a.m.e.mean()
    ly = a.lev0
    dyc = [a.names.index(f"dy_l{i}") for i in range(1, p)]
    n = len(y); T = n - start
    out = np.empty((reps, a.k))
    for r in range(reps):
        ys = y.copy()
        es = e[rng.integers(0, T, T)]
        Z = Z0.copy()
        for i, t in enumerate(range(start, n)):
            Z[i, ly] = ys[t - 1]
            for j, c in enumerate(dyc, 1):
                Z[i, c] = ys[t - j] - ys[t - j - 1]
            ys[t] = ys[t - 1] + Z[i] @ b + es[i]
        out[r] = ARDL(ys, X, p, q, fixed, start, trend, hac_lags=None).theta
    return out

"""01_data.py - Build the quarterly analysis dataset (2016Q1-2026Q1) from the raw BLS/FRED files.

Raw files (in ./data):
  All_Employees_retail_trade.xlsx             BLS CES4200000001 (monthly, SA, thousands)
  All_Employees_warehousing_and_storage.xlsx  BLS CES4349300001 (monthly, SA, thousands)
  ECOMPCTSA.xlsx                              Census e-commerce share of retail sales (quarterly, SA, %)
  GDPC1.xlsx                                  BEA real GDP (quarterly, SAAR, bn chained 2017 $)
  UNRATE.xlsx                                 BLS unemployment rate (monthly, SA, %)
  CPIAUCSL.xlsx                               BLS CPI-U (monthly, SA, 1982-84=100)
  CES4200000003.xlsx                          BLS avg hourly earnings, retail (quarterly, SA, $)

Monthly series are averaged to quarters (available months only: October 2025 CPI and UNRATE
were not collected because of the federal shutdown, so 2025Q4 is the Nov-Dec mean).
Output: data/quarterly.csv  (also quarterly_eoq.csv with end-of-quarter monthly values, used in R6)
"""
import os
import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, "data")
MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]


def read_bls(fname):
    raw = pd.read_excel(os.path.join(D, fname), header=None)
    hdr = raw.index[raw[0].astype(str).str.strip() == "Year"][0]
    tab = raw.iloc[hdr + 1:, :13].copy()
    tab.columns = ["Year"] + MONTHS
    tab = tab.dropna(subset=["Year"])
    long = tab.melt(id_vars="Year", var_name="m", value_name="v").dropna()
    long["date"] = pd.to_datetime(long["Year"].astype(int).astype(str) + "-" + long["m"] + "-01", format="%Y-%b-%d")
    return long.set_index("date")["v"].astype(float).sort_index()


def read_fred(fname, sheet):
    d = pd.read_excel(os.path.join(D, fname), sheet_name=sheet)
    d = d.set_index(pd.to_datetime(d.iloc[:, 0]))
    return d.iloc[:, 1].astype(float).sort_index()


def build(how="mean"):
    ret = read_bls("All_Employees_retail_trade.xlsx")
    war = read_bls("All_Employees_warehousing_and_storage.xlsx")
    unr = read_fred("UNRATE.xlsx", "Monthly")
    cpi = read_fred("CPIAUCSL.xlsx", "Monthly")
    ecom = read_fred("ECOMPCTSA.xlsx", "Quarterly")
    gdp = read_fred("GDPC1.xlsx", "Quarterly")
    wage = read_fred("CES4200000003.xlsx", "Quarterly")

    def q(s):
        s = s.dropna()
        g = s.groupby(s.index.to_period("Q"))
        return g.mean() if how == "mean" else g.last()

    def qq(s):  # already quarterly
        return s.set_axis(s.index.to_period("Q"))

    df = pd.DataFrame({"RET": q(ret), "WAR": q(war), "UNR": q(unr), "CPI": q(cpi),
                       "ECOM": qq(ecom), "GDP": qq(gdp), "WAGE": qq(wage)})
    df = df.loc["2016Q1":"2026Q1"].copy()
    df["NET"] = df["RET"] + df["WAR"]
    df["CPI_r"] = 100 * df["CPI"] / df.loc[pd.Period("2016Q1"), "CPI"]      # 2016Q1 = 100
    df["WAGE_real"] = df["WAGE"] * 100 / df["CPI_r"]                         # 2016Q1 dollars
    for v in ["RET", "WAR", "NET", "GDP", "WAGE_real"]:
        df["ln" + v] = np.log(df[v])
    df["D_COVID"] = [1.0 if p in (pd.Period("2020Q2"), pd.Period("2020Q3"), pd.Period("2020Q4")) else 0.0 for p in df.index]
    df["D_POST"] = [1.0 if p >= pd.Period("2020Q2") else 0.0 for p in df.index]
    for k, p in enumerate(["2020Q2", "2020Q3", "2020Q4"], 1):
        df[f"I{k}"] = (df.index == pd.Period(p)).astype(float)
    df.index = df.index.astype(str)
    df.index.name = "quarter"
    return df


if __name__ == "__main__":
    df = build("mean")
    df.to_csv(os.path.join(D, "quarterly.csv"))
    build("last").to_csv(os.path.join(D, "quarterly_eoq.csv"))
    print(df[["RET", "WAR", "ECOM", "GDP", "UNR", "WAGE", "CPI", "WAGE_real"]].round(3).to_string())

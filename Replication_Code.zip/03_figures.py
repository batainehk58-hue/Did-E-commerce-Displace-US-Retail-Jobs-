"""03_figures.py - Figures 1-5 of the paper (PNG, 300 dpi) from data/quarterly.csv.
Run after 01_data.py. Output: figures/fig1.png ... fig5.png
"""
import os, sys, warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from econ import OLS, ARDL, cusum, cusumsq_cv, select_ardl  # noqa

FIG = os.path.join(HERE, "figures"); os.makedirs(FIG, exist_ok=True)
plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman", "Liberation Serif", "DejaVu Serif"],
                     "mathtext.fontset": "stix", "font.size": 10, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.grid": True, "axes.grid.axis": "y", "grid.color": "#e6e6e6", "grid.linewidth": 0.6,
                     "legend.frameon": False, "savefig.dpi": 300, "savefig.bbox": "tight"})

d = pd.read_csv(os.path.join(HERE, "data", "quarterly.csv"), index_col=0).loc[:"2025Q4"]
d["lnNET"] = np.log(d.NET)
Q = list(d.index); n = len(d)
x = np.array([int(q[:4]) + (int(q[-1]) - 1) / 4 for q in Q])      # decimal year, 2016Q1 = 2016.00
X20 = 2020.25                                                      # 2020Q2
yrs = list(range(2016, 2026))


def vline(ax):
    ax.axvline(X20, color="#555555", ls=":", lw=1)


# Figure 1 --------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(7.5, 3.9))
for v, lab, st in [("RET", "Retail trade employment", dict(color="black", lw=2)),
                   ("WAR", "Warehousing & storage employment", dict(color="#777777", lw=2, ls="--")),
                   ("ECOM", "E-commerce share of retail sales", dict(color="#333333", lw=1.4, ls="-."))]:
    ax.plot(x, 100 * d[v] / d[v].iloc[0], label=lab, **st)
ax.axhline(100, color="#999999", lw=0.8); vline(ax)
ax.set_ylabel("Index, 2016Q1 = 100"); ax.set_xticks(yrs)
ax.legend(loc="center right", bbox_to_anchor=(1.0, 0.45))
fig.savefig(os.path.join(FIG, "fig1.png")); plt.close(fig)

# Figure 2 --------------------------------------------------------------------
fig, (a1, a2) = plt.subplots(1, 2, figsize=(10, 4))
a1.plot(x, d.RET - d.RET.iloc[0], color="black", lw=2, label="Retail")
a1.plot(x, d.WAR - d.WAR.iloc[0], color="#777777", lw=2, ls="--", label="Warehousing")
a1.plot(x, d.NET - d.NET.iloc[0], color="#333333", lw=1.4, ls=":", label="Retail + warehousing")
a1.axhline(0, color="#999999", lw=0.8); vline(a1)
a1.set_title("(a) Cumulative employment change", fontsize=11)
a1.set_ylabel("Change since 2016Q1 (thousands)"); a1.legend(loc="lower right"); a1.set_xticks(yrs[::2])
tt = np.arange(n, dtype=float); Xt = np.column_stack([np.ones(n), tt])
dev = {}
for v in ["lnRET", "ECOM"]:
    b = OLS(d[v].values[:17], Xt[:17]).b
    dev[v] = d[v].values - Xt @ b
a2.axvspan(x[0], x[16], color="#f0f0f0", zorder=0)
a2.plot(x, 100 * (np.exp(dev["lnRET"]) - 1), color="black", lw=2, label="Retail employment (%)")
a2.plot(x, dev["ECOM"], color="#777777", lw=2, ls="--", label="E-commerce share (pp)")
a2.axhline(0, color="#999999", lw=0.8); vline(a2)
a2.set_title("(b) Deviation from pre-2020 linear trend", fontsize=11)
a2.set_ylabel("Deviation from 2016Q1–2020Q1 trend"); a2.legend(loc="lower right"); a2.set_xticks(yrs[::2])
fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig2.png")); plt.close(fig)

# Figure 3 --------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(6.3, 4.3))
pre, post = slice(0, 17), slice(17, 40)
ax.scatter(d.ECOM.values[pre], d.lnRET.values[pre], facecolors="white", edgecolors="black", s=28, label="2016Q1–2020Q1")
ax.scatter(d.ECOM.values[post], d.lnRET.values[post], marker="^", color="#555555", s=30, label="2020Q2–2025Q4")
for sl, ls in [(slice(0, 17), "-"), (slice(19, 40), "--")]:
    xe, ye = d.ECOM.values[sl], d.lnRET.values[sl]
    b = OLS(ye, np.column_stack([np.ones(len(xe)), xe])).b
    g = np.linspace(xe.min(), xe.max(), 10)
    ax.plot(g, b[0] + b[1] * g, color="black", ls=ls, lw=1.2)
for qq, dx, dy_ in [("2020Q2", -0.1, 0.004), ("2020Q3", -0.1, 0.004)]:
    i = Q.index(qq)
    ax.annotate(qq, (d.ECOM.values[i], d.lnRET.values[i]), xytext=(d.ECOM.values[i] + dx, d.lnRET.values[i] + dy_),
                fontsize=8, ha="right")
ax.set_xlabel("E-commerce share of retail sales (%)"); ax.set_ylabel("ln retail employment")
ax.grid(True, axis="both"); ax.legend(loc="lower left")
fig.savefig(os.path.join(FIG, "fig3.png")); plt.close(fig)

# Figure 4 --------------------------------------------------------------------
Xv = d[["ECOM", "lnGDP", "UNR", "lnWAGE_real"]].values; fx = d[["D_COVID"]].values
fig, axs = plt.subplots(2, 3, figsize=(10, 5.4))
for j, (dep, title) in enumerate([("lnRET", "Model 1: retail"), ("lnWAR", "Model 2: warehousing"), ("lnNET", "Model 3: net")]):
    p, q = select_ardl(d[dep].values, Xv, fixed=fx)
    a = ARDL(d[dep].values, Xv, p, q, fixed=fx)
    W, band, S, w = cusum(a.m.y, a.m.X)
    k = a.m.X.shape[1]
    xs = x[4 + k:]                     # date of each recursive residual
    axs[0, j].plot(xs, W, color="black", lw=1.4)
    axs[0, j].plot(xs, band, color="#777777", ls="--", lw=1); axs[0, j].plot(xs, -band, color="#777777", ls="--", lw=1)
    cv = cusumsq_cv(a.m.n, k)
    line = np.arange(1, len(S) + 1) / len(S)
    axs[1, j].plot(xs, S, color="black", lw=1.4)
    axs[1, j].plot(xs, line + cv, color="#777777", ls="--", lw=1); axs[1, j].plot(xs, line - cv, color="#777777", ls="--", lw=1)
    axs[0, j].set_title(title, fontsize=11)
    for r in range(2):
        tk = [t for t in range(2019, 2026) if xs[0] - 0.01 <= t <= xs[-1]]
        axs[r, j].set_xticks(tk); axs[r, j].set_xticklabels([str(t) for t in tk], fontsize=8)
axs[0, 0].set_ylabel("CUSUM"); axs[1, 0].set_ylabel("CUSUM of squares")
fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig4.png")); plt.close(fig)

# Figure 5 --------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(6.5, 3.8))
ax.plot(x, d.WAGE, color="#777777", ls="--", lw=1.8, label="Nominal ($/hour)")
ax.plot(x, d.WAGE_real, color="black", lw=2, label="Real (2016Q1 $/hour)")
vline(ax); ax.set_xticks(yrs); ax.set_ylabel("Average hourly earnings, retail trade"); ax.legend(loc="upper left")
fig.savefig(os.path.join(FIG, "fig5.png")); plt.close(fig)
print("figures written to", FIG)
